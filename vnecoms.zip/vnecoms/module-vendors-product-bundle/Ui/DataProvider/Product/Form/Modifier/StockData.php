<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Vnecoms\VendorsProductBundle\Ui\DataProvider\Product\Form\Modifier;

/**
 * Class StockData hides unnecessary fields in Advanced Inventory Modal
 */
class StockData extends \Magento\Bundle\Ui\DataProvider\Product\Form\Modifier\StockData
{
    
}
