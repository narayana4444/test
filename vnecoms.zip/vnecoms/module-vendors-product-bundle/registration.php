<?php
/**
 * Copyright © 2018 Vnecoms, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Vnecoms_VendorsProductBundle',
    __DIR__
);
