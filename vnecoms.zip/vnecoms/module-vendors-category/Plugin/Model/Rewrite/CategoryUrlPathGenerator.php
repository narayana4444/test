<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Vnecoms\VendorsCategory\Plugin\Model\Rewrite;

class CategoryUrlPathGenerator
{
    public function afterGetUrlPath(\Magento\Catalog\Model\Product $product, $result)
    {
    }
}
