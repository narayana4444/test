<?php

namespace Vnecoms\VendorsCategory\Block;

use Magento\Framework\View\Element\Template;

/**
 * Rewrite some javascript paths
 * Class Head.
 */
class Head extends Template
{
}
