<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Vnecoms\VendorsFeaturedProduct\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface for template search results.
 * @api
 */
interface FeaturedSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get Reponses list.
     *
     * @return \Vnecoms\VendorsFeaturedProduct\Api\Data\FeaturedInterface[]
     */
    public function getItems();

    /**
     * Set Reponses list.
     *
     * @param \Vnecoms\VendorsFeaturedProduct\Api\Data\FeaturedInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
