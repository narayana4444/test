<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Customer attribute resource model
 *
 * @author      Magento Core Team <core@magentocommerce.com>
 */
namespace Vnecoms\Vendors\Model\ResourceModel;

class Attribute extends \Magento\Eav\Model\ResourceModel\Entity\Attribute
{


}
