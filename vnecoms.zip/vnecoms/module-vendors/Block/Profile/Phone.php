<?php
namespace Vnecoms\Vendors\Block\Profile;

/**
 * Class View
 * @package Vnecoms\Vendors\Block\Profile\Phone
 */
class Phone extends \Vnecoms\Vendors\Block\Profile
{
    
}
