<?php
namespace Vnecoms\Vendors\Block\Profile;

/**
 * Class View
 * @package Vnecoms\Vendors\Block\Profile\Description
 */
class Description extends \Vnecoms\Vendors\Block\Profile
{
    
}
