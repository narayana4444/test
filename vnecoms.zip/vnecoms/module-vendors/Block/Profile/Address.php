<?php
namespace Vnecoms\Vendors\Block\Profile;

/**
 * Class View
 * @package Vnecoms\Vendors\Block\Profile\Address
 */
class Address extends \Vnecoms\Vendors\Block\Profile
{
    
}
