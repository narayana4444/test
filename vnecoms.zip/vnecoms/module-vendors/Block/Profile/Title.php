<?php
namespace Vnecoms\Vendors\Block\Profile;

/**
 * Class View
 * @package Vnecoms\Vendors\Block\Profile\Content
 */
class Title extends \Vnecoms\Vendors\Block\Profile
{
    
}
