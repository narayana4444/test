<?php
namespace Vnecoms\Vendors\Block\Profile;

/**
 * Class View
 * @package Vnecoms\Vendors\Block\Profile\OpenTime
 */
class OpenTime extends \Vnecoms\Vendors\Block\Profile
{
    
}
