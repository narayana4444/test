<?php
namespace Vnecoms\Vendors\Block\Profile;

/**
 * Class View
 * @package Vnecoms\Vendors\Block\Profile\JoinedDate
 */
class JoinedDate extends \Vnecoms\Vendors\Block\Profile
{
    
}
