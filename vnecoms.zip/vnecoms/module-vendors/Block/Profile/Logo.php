<?php
namespace Vnecoms\Vendors\Block\Profile;

/**
 * Class View
 * @package Vnecoms\Vendors\Block\Profile\Logo
 */
class Logo extends \Vnecoms\Vendors\Block\Profile
{
    
}
