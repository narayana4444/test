<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Vnecoms\VendorsProductForm\Helper;

use Magento\Framework\App\Helper\AbstractHelper;

/**
 * @SuppressWarnings(PHPMD.LongVariable)
 */
class Data extends AbstractHelper
{
    const USE_SELECT_AND_SELL  = 'vendors/quick_add_product/can_select_and_sell';

    /**
     * @return bool
     */
    public function canUseSelectAndSell(){
        return (bool)$this->scopeConfig->getValue(self::USE_SELECT_AND_SELL);
    }
}
