<?php

namespace Vnecoms\VendorsProductForm\Plugin;

use Magento\Catalog\Model\Category as CategoryModel;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\ArrayManager;
use Magento\Framework\UrlInterface;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory as AttributeSetCollectionFactory;
use Magento\Store\Model\StoreManagerInterface;
use Vnecoms\VendorsProduct\Helper\Data as VendorProductHelper;
use Magento\Catalog\Model\ResourceModel\Product as ProductResource;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollectionFactory;
use Magento\Framework\DB\Helper as DbHelper;


class ProductList
{
    /**#@+
     * Category tree cache id
     */
    const CATEGORY_TREE_ID = 'CATALOG_PRODUCT_CATEGORY_TREE';

    /**
     * @var ArrayManager
     */
    protected $arrayManager;

    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     * @var VendorProductHelper
     */
    protected $helper;

    /**
     * @var AttributeSetCollectionFactory
     */
    protected $attributeSetCollectionFactory;

    /**
     * @var ProductResource
     */
    protected $productResource;

    /**
     * @var CategoryCollectionFactory
     */
    protected $categoryCollectionFactory;

    /**
     * @var CacheInterface
     */
    protected $cacheManager;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var \Magento\Framework\Locale\ResolverInterface
     */
    protected $localeResolver;

    /**
     * @var DbHelper
     * @since 101.0.0
     */
    protected $dbHelper;

    /**
     * @var SerializerInterface
     */
    private $serializer;

    /**
     * @var \Vnecoms\VendorsProduct\Model\Source\Approval
     */
    protected $approvalSource;

    /**
     * @var array
     */
    protected $productAttributes;

    /**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $request;

    /**
     * ProductList constructor.
     * @param ArrayManager $arrayManager
     * @param UrlInterface $urlBuilder
     * @param VendorProductHelper $vendorProductHelper
     * @param AttributeSetCollectionFactory $attributeSetCollectionFactory
     * @param ProductResource $productResource
     * @param CategoryCollectionFactory $categoryCollectionFactory
     * @param StoreManagerInterface $storeManager
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\Locale\ResolverInterface $localeResolver
     * @param \Vnecoms\VendorsProduct\Model\Source\Approval $approvalSource
     * @param DbHelper $dbHelper
     * @param SerializerInterface|null $serializer
     */
    public function __construct(
        ArrayManager $arrayManager,
        UrlInterface $urlBuilder,
        VendorProductHelper $vendorProductHelper,
        AttributeSetCollectionFactory $attributeSetCollectionFactory,
        ProductResource $productResource,
        CategoryCollectionFactory $categoryCollectionFactory,
        StoreManagerInterface $storeManager,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Locale\ResolverInterface $localeResolver,
        \Vnecoms\VendorsProduct\Model\Source\Approval $approvalSource,
        \Magento\Framework\App\Request\Http $request,
        DbHelper $dbHelper,
        SerializerInterface $serializer = null
    ) {
        $this->arrayManager = $arrayManager;
        $this->request = $request;
        $this->urlBuilder = $urlBuilder;
        $this->helper = $vendorProductHelper;
        $this->attributeSetCollectionFactory = $attributeSetCollectionFactory;
        $this->productResource = $productResource;
        $this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->localeResolver = $localeResolver;
        $this->approvalSource = $approvalSource;
        $this->dbHelper = $dbHelper;
        $this->serializer = $serializer ?: ObjectManager::getInstance()->get(SerializerInterface::class);
    }

    /**
     * @param \Vnecoms\VendorsProduct\Ui\DataProvider\Product\Vendor\ProductDataProvider $subject
     * @param $result
     */
    public function afterGetMeta(
        \Vnecoms\VendorsProduct\Ui\DataProvider\Product\Vendor\ProductDataProvider $subject,
        $meta
    ) {
        $controller = $this->request->getControllerName();
        $action     = $this->request->getActionName();
        $route      = $this->request->getRouteName();

        $meta = $this->createNewProductTagsModal($meta);
        $meta = $this->createProductAdditionalForm($meta);

        $meta['product_columns']['arguments']['data']['config']['base_product_image_url'] = $this->urlBuilder->getBaseUrl(['_type' => UrlInterface::URL_TYPE_MEDIA]).'catalog/product/';
        $meta['product_columns']['arguments']['data']['config']['saveProductUrl'] = $this->urlBuilder->getUrl('catalog/product/updateProductInfo');
        $meta['product_columns']['arguments']['data']['config']['deleteProductUrl'] = $this->urlBuilder->getUrl('catalog/product/deleteProduct');
        $meta['product_columns']['arguments']['data']['config']['approveProductUrl'] = $this->urlBuilder->getUrl('catalog/product/approveProduct');
        $meta['product_columns']['arguments']['data']['config']['editProductUrl'] = $this->urlBuilder->getUrl('catalog/product/edit');
        $meta['product_columns']['arguments']['data']['config']['attributeSets'] = $this->getAttributeSetOptions();
        $meta['product_columns']['arguments']['data']['config']['categories'] = $this->getCategoriesTree();
        $meta['product_columns']['arguments']['data']['config']['currency_symbol'] = $this->storeManager->getStore()->getBaseCurrency()->getCurrencySymbol();
        $meta['product_columns']['arguments']['data']['config']['approvalSource'] = $this->approvalSource->getOptionArray();
        if ($route == "catalog" && $controller == "product" && $action == "index") {
            $fieldsCategory = $this->customizeCategoriesField($meta);
            $meta['product_columns']['children']['category'] = $fieldsCategory['category'];
        }

        return $meta;
    }


    /**
     * get list of products attributes
     */
    protected function getProductAttributes(){
        if(!$this->productAttributes){
            $this->productAttributes = [];
            $om = \Magento\Framework\App\ObjectManager::getInstance();
            $productAttrCollection = $om->create('Magento\Catalog\Model\ResourceModel\Product\Attribute\Collection')
                ->addVisibleFilter();
            foreach($productAttrCollection as $attribute){
                $this->productAttributes[$attribute->getAttributeCode()] = $attribute;
            }
        }

        return $this->productAttributes;
    }
    /**
     * Get pending updates
     * @return array
     */
    protected function getPendingUpdates($productId){
        $update = \Magento\Framework\App\ObjectManager::getInstance()->create('Vnecoms\VendorsProduct\Model\Product\Update');
        /*Check if there is an exist pending update*/
        $collection = $update->getCollection()
            ->addFieldToFilter('product_id', $productId)
            ->addFieldToFilter('status', \Vnecoms\VendorsProduct\Model\Product\Update::STATUS_PENDING);
        $result = [];
        $attributes = $this->getProductAttributes();
        foreach($collection as $update){
            $updateData = $update->getData();
            $productData = unserialize($updateData['product_data']);
            foreach($productData as $attrCode => $value){
                if(isset($attributes[$attrCode])){
                    $result[] = ['label' => $attributes[$attrCode]->getFrontendLabel(), 'value' => $value];
                }else{
                    $result[] = ['label' => $attrCode, 'value' => $value];
                }
            }
            $updateData['product_data'] =  $productData;
            break;
        }
        return $result;
    }
    protected function customizeCategoriesField()
    {
        return [
            'category' => [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'label' => __('Categories'),
                            'dataScope' => '',
                            'breakLine' => false,
                            'formElement' => 'container',
                            'componentType' => 'container',
                            'component' => 'Magento_Ui/js/form/components/group',
                            'sortOrder' => 10,
                            'displayArea' => 'productCategories',
                            'additionalClasses' => 'admin__field-clean',
                        ],
                    ],
                ],
                'children' => [
                    'category' => [
                        'arguments' => [
                            'data' => [
                                'config' => [
                                    'formElement' => 'select',
                                    'componentType' => 'field',
                                    'component' => 'Vnecoms_VendorsProductForm/js/components/category',
                                    'filterOptions' => true,
                                    'chipsEnabled' => true,
                                    'disableLabel' => true,
                                    'levelsVisibility' => '2',
                                    'elementTmpl' => 'Vnecoms_VendorsProductForm/category-ui-select',
                                    'options' => $this->getCategoriesTree(),
                                    'config' => [
                                        'dataScope' => 'category',
                                        'sortOrder' => 10,
                                    ],
                                ],
                            ],
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * Create slide-out panel for new category creation.
     *
     * @param array $meta
     *
     * @return array
     */
    protected function createNewProductTagsModal(array $meta)
    {
        return $this->arrayManager->set(
            'ves_upload_product_images',
            $meta,
            [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'isTemplate' => false,
                            'componentType' => 'modal',
                            'options' => [
                                'modalClass' => 'modal-product-images',
                                'type' => 'popup',
                                'title' => __('Product Images'),
                            ],
                            'imports' => [
                                'state' => '!index=ves_upload_product_image:responseStatus',
                            ],
                        ],
                    ],
                ],
                'children' => [
                    'ves_upload_product_image' => [
                        'arguments' => [
                            'data' => [
                                'config' => [
                                    'label' => '',
                                    'componentType' => 'container',
                                    'component' => 'Magento_Ui/js/form/components/insert-form',
                                    'dataScope' => '',
                                    'update_url' => $this->urlBuilder->getUrl('mui/index/render'),
                                    'render_url' => $this->urlBuilder->getUrl(
                                        'mui/index/render_handle',
                                        [
                                            'handle' => 'upload_product_image',
                                            'store' => 1,
                                            'buttons' => 1,
                                        ]
                                    ),
                                    'autoRender' => false,
                                    'ns' => 'upload_product_image',
                                    'externalProvider' => 'upload_product_image.upload_product_image_data_source',
                                    'toolbarContainer' => '${ $.parentName }',
                                    'formSubmitType' => 'ajax',
                                ],
                            ],
                        ],
                    ],
                ],
            ]
        );
    }


    protected function createProductAdditionalForm(array $meta)
    {
        return $this->arrayManager->set(
            'ves_product_additional_form',
            $meta,
            [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'isTemplate' => false,
                            'componentType' => 'modal',
                            'options' => [
                                'modalClass' => 'modal-product-additional',
                                'type' => 'popup',
                                'title' => __('Advanced options'),
                            ],
                            'imports' => [
                                'state' => '!index=ves_product_form_additional:responseStatus',
                            ],
                        ],
                    ],
                ],
                'children' => [
                    'ves_product_form_additional' => [
                        'arguments' => [
                            'data' => [
                                'config' => [
                                    'label' => '',
                                    'componentType' => 'container',
                                    'component' => 'Magento_Ui/js/form/components/insert-form',
                                    'dataScope' => '',
                                    'update_url' => $this->urlBuilder->getUrl('mui/index/render'),
                                    'render_url' => $this->urlBuilder->getUrl(
                                        'mui/index/render_handle',
                                        [
                                            'handle' => 'product_form_additional_form',
                                            'store' => 1,
                                            'buttons' => 1,
                                        ]
                                    ),
                                    'autoRender' => false,
                                    'ns' => 'product_form_additional_form',
                                    'externalProvider' => 'product_form_additional_form.product_form_additional_form_data_source',
                                    'toolbarContainer' => '${ $.parentName }',
                                    'formSubmitType' => 'ajax',
                                ],
                            ],
                        ],
                    ],
                ],
            ]
        );
    }


    /**
     * Return options for select
     *
     * @return array
     */
    protected function getAttributeSetOptions()
    {
        /** @var \Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\Collection $collection */
        $collection = $this->attributeSetCollectionFactory->create();
        $collection->setEntityTypeFilter($this->productResource->getTypeId())
            ->addFieldToSelect('attribute_set_id', 'value')
            ->addFieldToSelect('attribute_set_name', 'label')
            ->addFieldToFilter('attribute_set_id', ['nin'=>$this->helper->getAttributeSetRestriction()])
            ->setOrder(
                'attribute_set_name',
                \Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\Collection::SORT_ORDER_ASC
            );

        return $collection->getData();
    }

    /**
     * Retrieve cache interface
     *
     * @return CacheInterface
     * @deprecated 101.0.3
     */
    private function getCacheManager()
    {
        if (!$this->cacheManager) {
            $this->cacheManager = ObjectManager::getInstance()
                ->get(CacheInterface::class);
        }
        return $this->cacheManager;
    }


    /**
     * Get list of Locale for all stores
     * @return array
     */
    public function getStoreIdByCurrentLocale()
    {
        //Locale code
        $locale = [];
        $stores = $this->storeManager->getStores($withDefault = false);
        //Try to get list of locale for all stores;
        foreach($stores as $store) {
            $locale[$store->getStoreId()] = $this->scopeConfig->getValue('general/locale/code', \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $store->getStoreId());
        }
        $vendorLocaleCode =  $this->localeResolver->getLocale();;


        $key = array_search($vendorLocaleCode , $locale);
        return $key ? $key : 0;
    }

    /**
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    /**
     * Retrieve categories tree
     *
     * @param string|null $filter
     * @return array
     * @since 101.0.0
     */
    protected function getCategoriesTree($filter = null)
    {
        $categoryTree = $this->getCacheManager()->load(self::CATEGORY_TREE_ID . '_' . $filter);
        if ($categoryTree) {
            return $this->serializer->unserialize($categoryTree);
        }

        $storeId = $this->getStoreIdByCurrentLocale();
        /* @var $matchingNamesCollection \Magento\Catalog\Model\ResourceModel\Category\Collection */
        $matchingNamesCollection = $this->categoryCollectionFactory->create();

        if ($filter !== null) {
            $matchingNamesCollection->addAttributeToFilter(
                'name',
                ['like' => $this->dbHelper->addLikeEscape($filter, ['position' => 'any'])]
            );
        }

        $matchingNamesCollection->addAttributeToSelect('path')
            ->addAttributeToFilter('entity_id', ['neq' => CategoryModel::TREE_ROOT_ID])
            ->setStoreId($storeId);

        $shownCategoriesIds = [];

        /** @var \Magento\Catalog\Model\Category $category */
        foreach ($matchingNamesCollection as $category) {
            foreach (explode('/', $category->getPath()) as $parentId) {
                $shownCategoriesIds[$parentId] = 1;
            }
        }

        /* @var $collection \Magento\Catalog\Model\ResourceModel\Category\Collection */
        $collection = $this->categoryCollectionFactory->create();

        $collection->addAttributeToFilter('entity_id', ['in' => array_keys($shownCategoriesIds)])
            ->addAttributeToSelect(['name', 'is_active', 'parent_id'])
            ->setStoreId($storeId);

        $categoryById = [
            CategoryModel::TREE_ROOT_ID => [
                'value' => CategoryModel::TREE_ROOT_ID,
                'optgroup' => null,
            ],
        ];

        foreach ($collection as $category) {
            foreach ([$category->getId(), $category->getParentId()] as $categoryId) {
                if (!isset($categoryById[$categoryId])) {
                    $categoryById[$categoryId] = ['value' => $categoryId];
                }
            }

            $categoryById[$category->getId()]['is_active'] = $category->getIsActive();
            $categoryById[$category->getId()]['label'] = $category->getName();
            $categoryById[$category->getParentId()]['optgroup'][] = &$categoryById[$category->getId()];
        }

        $this->getCacheManager()->save(
            $this->serializer->serialize($categoryById[CategoryModel::TREE_ROOT_ID]['optgroup']),
            self::CATEGORY_TREE_ID . '_' . $filter,
            [
                \Magento\Catalog\Model\Category::CACHE_TAG,
                \Magento\Framework\App\Cache\Type\Block::CACHE_TAG
            ]
        );

        return $categoryById[CategoryModel::TREE_ROOT_ID]['optgroup'];
    }

    /**
     * @param \Vnecoms\VendorsProduct\Ui\DataProvider\Product\Vendor\ProductDataProvider $subject
     * @param $result
     */
    public function beforeGetData(
        \Vnecoms\VendorsProduct\Ui\DataProvider\Product\Vendor\ProductDataProvider $subject
    ) {
        $subject->getCollection()->addMediaGalleryData();
    }

    /**
     * @param array $a
     * @param array $b
     * @return int
     */
    public function sortImages($a, $b){
        if ($a['position'] == $b['position']) {
            return 0;
        }
        return ($a['position'] < $b['position']) ? -1 : 1;
    }

    /**
     * @param \Vnecoms\VendorsProduct\Ui\DataProvider\Product\Vendor\ProductDataProvider $subject
     * @param $result
     */
    public function afterGetData(
        \Vnecoms\VendorsProduct\Ui\DataProvider\Product\Vendor\ProductDataProvider $subject,
        $data
    ) {
        $products = [];
        $data['category_ids'] = [];
        foreach($subject->getCollection() as $product){
            $data['category_ids'][$product->getId()] = $product->getCategoryIds();
            $products[$product->getId()] = $product;
        }

        $items = $data['items'];
        foreach($items as $key=>$item){
            $items[$key]['pending_update'] = $this->getPendingUpdates($item['entity_id']);
            $items[$key]['approval_data'] = $products[$item['entity_id']]->getApproval();
            $price = isset($item['price'])?$item['price']:0;
            $items[$key]['price_origin'] = $price * 1;
            $items[$key]['qty'] = $item['qty'] * 1;
            usort($items[$key]['media_gallery']['images'], [$this, 'sortImages']);
        }

        $data['items'] = $items;
        return $data;
    }
}
