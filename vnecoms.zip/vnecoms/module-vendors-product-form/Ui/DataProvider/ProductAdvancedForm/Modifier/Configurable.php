<?php

namespace Vnecoms\VendorsProductForm\Ui\DataProvider\ProductAdvancedForm\Modifier;

use Magento\Catalog\Model\Locator\LocatorInterface;
use Magento\ConfigurableProduct\Ui\DataProvider\Product\Form\Modifier\Data\AssociatedProducts;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Model\ProductOptions\ConfigInterface;
use Magento\Catalog\Model\Config\Source\Product\Options\Price as ProductOptionsPrice;
use Magento\Framework\UrlInterface;
use Magento\Framework\Stdlib\ArrayManager;
use Magento\Ui\Component\Modal;
use Magento\Ui\Component\Container;
use Magento\Ui\Component\DynamicRows;
use Magento\Ui\Component\Form\Element\DataType\Price;
use Magento\Ui\Component\Form\Fieldset;
use Magento\Ui\Component\Form\Field;
use Magento\Ui\Component\Form\Element\Input;
use Magento\Ui\Component\Form\Element\Select;
use Magento\Ui\Component\Form\Element\Checkbox;
use Magento\Ui\Component\Form\Element\ActionDelete;
use Magento\Ui\Component\Form\Element\DataType\Text;
use Magento\Ui\Component\Form\Element\DataType\Number;
use Magento\Framework\Locale\CurrencyInterface;
use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractModifier;

/**
 * Data provider for "Customizable Options" panel
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Configurable extends AbstractModifier
{
    const GROUP_CONFIGURABLE_NAME   = 'configurable';
    const CONTAINER_HEADER_NAME     = 'container_header';
    const CONTAINER_OPTION_NAME     = 'configurable_options';
    const GRID_OPTIONS              = 'configurable_grid_options';

    /**
     * @var LocatorInterface
     * @since 101.0.0
     */
    protected $locator;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     * @since 101.0.0
     */
    protected $storeManager;

    /**
     * @var \Magento\Catalog\Model\ProductOptions\ConfigInterface
     * @since 101.0.0
     */
    protected $productOptionsConfig;

    /**
     * @var \Magento\Catalog\Model\Config\Source\Product\Options\Price
     * @since 101.0.0
     */
    protected $productOptionsPrice;

    /**
     * @var UrlInterface
     * @since 101.0.0
     */
    protected $urlBuilder;

    /**
     * @var ArrayManager
     * @since 101.0.0
     */
    protected $arrayManager;

    /**
     * @var array
     * @since 101.0.0
     */
    protected $meta = [];

    /**
     * @var CurrencyInterface
     */
    private $localeCurrency;

    /**
     * @var array
     */
    protected $configurableAttributeOptions;

    /**
     * @var array
     */
    protected $productOptions;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory
     */
    protected $configurableAttributeHandler;

    /**
     * @var AssociatedProducts
     */
    private $associatedProducts;
    /**
     * @param LocatorInterface $locator
     * @param StoreManagerInterface $storeManager
     * @param ConfigInterface $productOptionsConfig
     * @param ProductOptionsPrice $productOptionsPrice
     * @param UrlInterface $urlBuilder
     * @param ArrayManager $arrayManager
     */
    public function __construct(
        LocatorInterface $locator,
        StoreManagerInterface $storeManager,
        ConfigInterface $productOptionsConfig,
        ProductOptionsPrice $productOptionsPrice,
        UrlInterface $urlBuilder,
        AssociatedProducts $associatedProducts,
        \Magento\ConfigurableProduct\Model\ConfigurableAttributeHandler $configurableAttributeHandler,
        ArrayManager $arrayManager
    ) {
        $this->locator = $locator;
        $this->storeManager = $storeManager;
        $this->productOptionsConfig = $productOptionsConfig;
        $this->productOptionsPrice = $productOptionsPrice;
        $this->urlBuilder = $urlBuilder;
        $this->associatedProducts = \Magento\Framework\App\ObjectManager::getInstance()
            ->create('Magento\ConfigurableProduct\Ui\DataProvider\Product\Form\Modifier\Data\AssociatedProducts',['locator' => $locator]);
        $this->configurableAttributeHandler = $configurableAttributeHandler;
        $this->arrayManager = $arrayManager;
    }

    /**
     * {@inheritdoc}
     * @since 101.0.0
     */
    public function modifyData(array $data)
    {
        /** @var \Magento\Catalog\Model\Product $product */
        $product = $this->locator->getProduct();
        $productId = $product->getId();
        $isConfigurable = $product->getTypeId() == 'configurable';
        if($isConfigurable){
            $attributeOptions = $this->getProductOptions();
            $data[$productId]['configurable_options'] = [];
            $configurableAttributeData = $product->getTypeInstance()->getConfigurableOptions($product);
            foreach($configurableAttributeData as $attributeId => $attributeData){
                $option = ['option_attribute' => $attributeId];
                $option['option_values'] = [];
                foreach($attributeData as $value){
                    $option['option_values'][] = [
                        'value' => $value['value_index'],
                        'label' => $value['option_title'],
                    ];
                }
                $data[$productId]['configurable_options'][] = $option;
            }

            $data[$productId]['configurable_grid_options'] = $this->associatedProducts->getProductMatrix();
            $data[$productId]['attributes'] = $this->associatedProducts->getProductAttributesIds();
            $data[$productId]['attribute_codes'] = $this->associatedProducts->getProductAttributesCodes();
            $data[$productId]['product']['configurable_attributes_data'] =
            $this->associatedProducts->getConfigurableAttributesData();
        }
        return $data;
    }

    /**
     * @return array
     */
    protected function getProductOptions(){
        if(!$this->productOptions){
            $this->initProductOptions();
        }
        return $this->productOptions;
    }


    /**
     * {@inheritdoc}
     * @since 101.0.0
     */
    public function modifyMeta(array $meta)
    {
        $this->meta = $meta;

        $this->getConfigurableFieldset();

        return $this->meta;
    }

    protected function getConfigurableFieldset(){
        $this->meta[static::GROUP_CONFIGURABLE_NAME] = [
            'arguments' => [
                'data' => [
                    'config' => [
                        'label' => __('Configurable Options'),
                        'componentType' => Fieldset::NAME,
                        'collapsible' => false,
                    ],
                ],
            ],
            'children' => [
                static::CONTAINER_HEADER_NAME   => $this->getHeaderContainerConfig(10),
                static::CONTAINER_OPTION_NAME   => $this->getOptionNameConfig(20),
                static::GRID_OPTIONS            => $this->getOptionsGridConfig(30),
            ]
        ];
    }

    /**
     * Get config for header container
     *
     * @param int $sortOrder
     * @return array
     * @since 101.0.0
     */
    protected function getHeaderContainerConfig($sortOrder)
    {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'label' => null,
                        'formElement' => Container::NAME,
                        'componentType' => Container::NAME,
                        'template' => 'ui/form/components/complex',
                        'sortOrder' => $sortOrder,
                        'content' => __('Configurable products allow customers to choose options (Ex: shirt color). You need to create a simple product for each configuration (Ex: a product for each color)..'),
                    ],
                ],
            ],
        ];
    }

    /**
     * @return array
     */
    protected function getConfigurableAttributeOptions(){
        if(!$this->configurableAttributeOptions){
            $this->initProductOptions();
        }
        return $this->configurableAttributeOptions;
    }

    /**
     * Init product options
     */
    protected function initProductOptions(){
        $this->productOptions = [];
        $attributes = $this->configurableAttributeHandler->getApplicableAttributes();
        $options = [];
        foreach($attributes as $attribute){
            $attrData = ['label' => $attribute->getFrontendLabel(), 'code' => $attribute->getAttributeCode(),'id' => $attribute->getId()];
            $attrOptions = $attribute->getSource()->getAllOptions();
            $otps = [];
            foreach($attrOptions as $option){
                if($option['value']){
                    $otps[] = $option;
                    $this->productOptions[$option['value']] = $option['label'];
                }
            }
            $attrData['options'] = $otps;
            $options[$attribute->getId().""] = $attrData;
        }
        $this->configurableAttributeOptions = $options;
    }

    /**
     * @return array
     */
    protected function getConfigurableAttributes(){
        $attributes = $this->configurableAttributeHandler->getApplicableAttributes();
        $options = [];
        foreach($attributes as $attribute){
            $options[] = ['value' => $attribute->getId(), 'label' => $attribute->getFrontendLabel()];
        }
        return $options;
    }

    /**
     * @param $sortOrder
     * @return array
     */
    protected function getOptionNameConfig($sortOrder){

        $product = $this->locator->getProduct();
        return [
            'arguments' =>[
                'data' => [
                    'config' => [
                        'formElement' => 'container',
                        'componentType' => 'container',
                        'label' => __('Option'),
                        'breakLine' => false,
                        'sortOrder' => $sortOrder,
                    ]
                ]
            ],
            'children' => [
                'configurable_options' => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'componentType' => 'container',
                                'component' => 'Vnecoms_VendorsProductForm/js/dynamic-rows/product-option',
                                'attributes' => $this->getConfigurableAttributeOptions(),
                                'template' => 'ui/dynamic-rows/templates/default',
                                'label' => __('Product Option'),
                                'defaultRecord' => false,
                                'columnsHeader' => false,
                                'recordTemplate' => 'record',
                                'dndConfig' => [
                                    'enabled' => false,
                                ],
                                'editMode' => !$product->getId(),
                                'maxPosition'=> 3,
                                'currency_symbol' => $this->getCurrencySymbol(),
                                'disabled' => false,
                            ],
                        ],
                    ],
                    'children' => [
                        'record' => [
                            'arguments' => [
                                'data' => [
                                    'config' => [
                                        'componentType' => Container::NAME,
                                        'isTemplate' => true,
                                        'is_collection' => true,
                                        'component' => 'Magento_Ui/js/dynamic-rows/record',
                                        'dataScope' => '',
                                    ],
                                ],
                            ],
                            'children' => [
                                'option_attribute' => [
                                    'arguments' => [
                                        'data' => [
                                            'config' => [
                                                'formElement' => 'select',
                                                'componentType' => Field::NAME,
                                                'dataType' => 'text',
                                                'label' => __('Attribute'),
                                                'dataScope' => 'option_attribute',
                                                'options' => $this->getConfigurableAttributes()
                                            ],
                                        ],
                                    ],
                                ],
                                'option_values' => [
                                    'arguments' => [
                                        'data' => [
                                            'config' => [
                                                'componentType' => Field::NAME,
                                                'formElement' => Input::NAME,
                                                'dataType' => Price::NAME,
                                                'label' => __('Value'),
                                                'enableLabel' => true,
                                                'dataScope' => 'option_values',
                                                'elementTmpl' => 'Vnecoms_VendorsProductForm/form/option-value',
                                                'component' => 'Vnecoms_VendorsProductForm/js/form/option-value',
                                            ],
                                        ],
                                    ],
                                ],
                                'actionDelete' => [
                                    'arguments' => [
                                        'data' => [
                                            'config' => [
                                                'componentType' => 'actionDelete',
                                                'dataType' => Text::NAME,
                                                'label' => '',
                                            ],
                                        ],
                                    ],
                                ],
                            ],
                        ],
                    ],
                ]
            ]
        ];
    }

    /**
     * Get currency symbol
     *
     * @return string
     * @since 101.0.0
     */
    protected function getCurrencySymbol()
    {
        return $this->storeManager->getStore()->getBaseCurrency()->getCurrencySymbol();
    }

    /**
     * Get duration dynamic rows structure
     *
     * @param string $durationPath
     * @return array
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function getOptionsGridConfig()
    {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => 'dynamicRows',
                        'label' => __('Configurable Options'),
                        'renderDefaultRecord' => false,
                        'recordTemplate' => 'record',
                        'dataScope' => '',
                        'addButton' => false,
                        'dndConfig' => [
                            'enabled' => false,
                        ],
                        'disabled' => false,
                    ],
                ],
            ],
            'children' => [
                'record' => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'componentType' => Container::NAME,
                                'isTemplate' => true,
                                'is_collection' => true,
                                'component' => 'Magento_Ui/js/dynamic-rows/record',
                                'dataScope' => '',
                            ],
                        ],
                    ],
                    'children' => [
                        'duration' => [
                            'arguments' => [
                                'data' => [
                                    'config' => [
                                        'formElement' => Input::NAME,
                                        'componentType' => Field::NAME,
                                        'dataType' => Number::NAME,
                                        'label' => __('SKU'),
                                        'dataScope' => 'sku',
                                        'validation' => [
                                            'required-entry' => true
                                        ],
                                    ],
                                ],
                            ],
                        ],
                        'options' => [
                            'arguments' => [
                                'data' => [
                                    'config' => [
                                        'formElement' => Input::NAME,
                                        'componentType' => Field::NAME,
                                        'dataType' => Text::NAME,
                                        'dataScope' => 'attributes',
                                        'label' => __('Options'),
                                        'options' => [],
                                        'elementTmpl' => 'ui/form/element/text',
                                    ],
                                ],
                            ],
                        ],
                        'price' => [
                            'arguments' => [
                                'data' => [
                                    'config' => [
                                        'componentType' => Field::NAME,
                                        'formElement' => Input::NAME,
                                        'dataType' => Price::NAME,
                                        'label' => __('Price'),
                                        'enableLabel' => true,
                                        'dataScope' => 'price',
                                        'additionalClasses' => 'number-input',
                                        'validation' => [
                                            'required-entry' => true,
                                            'validate-greater-than-zero' => false,
                                            'validate-number' => true,
                                        ],
                                        'addbefore' => $this->getCurrencySymbol(),
                                    ],
                                ],
                            ],
                        ],
                        'weight' => [
                            'arguments' => [
                                'data' => [
                                    'config' => [
                                        'componentType' => Field::NAME,
                                        'formElement' => Input::NAME,
                                        'dataType' => Number::NAME,
                                        'label' => __('Weight'),
                                        'enableLabel' => true,
                                        'dataScope' => 'weight',
                                        'additionalClasses' => 'number-input',
                                        'validation' => [
                                            'required-entry' => true,
                                            'validate-greater-than-zero' => false,
                                            'validate-number' => true,
                                        ],
                                    ],
                                ],
                            ],
                        ],
                        'sort_order' => [
                            'arguments' => [
                                'data' => [
                                    'config' => [
                                        'formElement' => Input::NAME,
                                        'componentType' => Field::NAME,
                                        'dataType' => Number::NAME,
                                        'additionalClasses' => 'number-input',
                                        'label' => __('QTY'),
                                        'dataScope' => 'qty',
                                    ],
                                ],
                            ],
                        ],
                        'actionDelete' => [
                            'arguments' => [
                                'data' => [
                                    'config' => [
                                        'componentType' => 'actionDelete',
                                        'dataType' => Text::NAME,
                                        'label' => '',
                                    ],
                                ],
                            ],
                        ],
                    ],
                ],
            ],
        ];
    }
}
